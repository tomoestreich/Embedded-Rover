/*******************************************************************************
  MPLAB Harmony Application Source File
  
  Company:
    Microchip Technology Inc.
  
  File Name:
    motor_thread.c

  Summary:
    This file contains the source code for the MPLAB Harmony application.

  Description:
    This file contains the source code for the MPLAB Harmony application.  It 
    implements the logic of the application's state machine and it may call 
    API routines of other MPLAB Harmony modules in the system, such as drivers,
    system services, and middleware.  However, it does not call any of the
    system interfaces (such as the "Initialize" and "Tasks" functions) of any of
    the modules in the system or make any assumptions about when those functions
    are called.  That is the responsibility of the configuration-specific system
    files.
 *******************************************************************************/


// *****************************************************************************
// *****************************************************************************
// Section: Included Files 
// *****************************************************************************
// *****************************************************************************

#include "motor_thread.h"
#include "system_config/default/framework/driver/oc/drv_oc_static.h"
#include "peripheral/oc/plib_oc.h"
#include "message.h"
#include "debug.h"

// *****************************************************************************
// *****************************************************************************
// Section: Global Data Definitions
// *****************************************************************************
// *****************************************************************************

// *****************************************************************************

#define MOTOR_ONE_DIR_PORT  PORT_CHANNEL_C
#define MOTOR_ONE_DIR_BIT   PORTS_BIT_POS_14
#define MOTOR_ONE_PWM_PORT  PORT_CHANNEL_D
#define MOTOR_ONE_PWM_BIT   PORTS_BIT_POS_0

#define MOTOR_TWO_DIR_PORT  PORT_CHANNEL_G
#define MOTOR_TWO_DIR_BIT   PORTS_BIT_POS_1
#define MOTOR_TWO_PWM_PORT  PORT_CHANNEL_D
#define MOTOR_TWO_PWM_BIT   PORTS_BIT_POS_1

#define PWM_MAX_DUTY_CYCLE  655
#define PWM_90_PERCENT      590
#define PWM_80_PERCENT      524
#define PWM_70_PERCENT      459
#define PWM_60_PERCENT      393
#define PWM_50_PERCENT      328
#define PWM_40_PERCENT      262
#define PWM_30_PERCENT      197
#define PWM_20_PERCENT      131
#define PWM_10_PERCENT      66

#define TICKS_PER_90_TURN   325

#define LEFT_ENCODER        OC_ID_2
#define RIGHT_ENCODER       OC_ID_1

MOTOR_THREAD_DATA motor_threadData;
extern QueueHandle_t motorQueue;
static uint32_t left_encoder_count, right_encoder_count;

// *****************************************************************************
// *****************************************************************************
// Section: Application Local Functions
// *****************************************************************************
// *****************************************************************************

void increment_left_encoder(){
    left_encoder_count++;
}

void increment_right_encoder(){
    right_encoder_count++;
}

void turn_left(){
    PLIB_OC_PulseWidth16BitSet(RIGHT_ENCODER, PWM_MAX_DUTY_CYCLE);
    PLIB_OC_PulseWidth16BitSet(LEFT_ENCODER, PWM_MAX_DUTY_CYCLE);
    
    vTaskDelay(200);
    
    PLIB_OC_PulseWidth16BitSet(RIGHT_ENCODER, 0);
    PLIB_OC_PulseWidth16BitSet(LEFT_ENCODER, 0);
    
    // Set motor directions
    PLIB_PORTS_PinWrite(PORTS_ID_0, MOTOR_ONE_DIR_PORT, MOTOR_ONE_DIR_BIT, 0);
    PLIB_PORTS_PinWrite(PORTS_ID_0, MOTOR_TWO_DIR_PORT, MOTOR_TWO_DIR_BIT, 1);
    
    PLIB_OC_PulseWidth16BitSet(RIGHT_ENCODER, PWM_MAX_DUTY_CYCLE);
    PLIB_OC_PulseWidth16BitSet(LEFT_ENCODER, PWM_MAX_DUTY_CYCLE);
    
    vTaskDelay(TICKS_PER_90_TURN);
    
    PLIB_OC_PulseWidth16BitSet(RIGHT_ENCODER, 0);
    PLIB_OC_PulseWidth16BitSet(LEFT_ENCODER, 0);
    
    // Reset motor directions
    PLIB_PORTS_PinWrite(PORTS_ID_0, MOTOR_ONE_DIR_PORT, MOTOR_ONE_DIR_BIT, 0);
    PLIB_PORTS_PinWrite(PORTS_ID_0, MOTOR_TWO_DIR_PORT, MOTOR_TWO_DIR_BIT, 0);
}

void turn_around(){
    // Set motor directions
    PLIB_PORTS_PinWrite(PORTS_ID_0, MOTOR_ONE_DIR_PORT, MOTOR_ONE_DIR_BIT, 0);
    PLIB_PORTS_PinWrite(PORTS_ID_0, MOTOR_TWO_DIR_PORT, MOTOR_TWO_DIR_BIT, 1);
            
    PLIB_OC_PulseWidth16BitSet(RIGHT_ENCODER, PWM_MAX_DUTY_CYCLE);
    PLIB_OC_PulseWidth16BitSet(LEFT_ENCODER, PWM_MAX_DUTY_CYCLE);
    
    vTaskDelay(TICKS_PER_90_TURN);
    vTaskDelay(TICKS_PER_90_TURN);
    
    PLIB_OC_PulseWidth16BitSet(OC_ID_1, 0);
    PLIB_OC_PulseWidth16BitSet(OC_ID_2, 0);
    
    // Reset motor directions
    PLIB_PORTS_PinWrite(PORTS_ID_0, MOTOR_ONE_DIR_PORT, MOTOR_ONE_DIR_BIT, 0);
    PLIB_PORTS_PinWrite(PORTS_ID_0, MOTOR_TWO_DIR_PORT, MOTOR_TWO_DIR_BIT, 0);
}

void turn_right(){
    PLIB_OC_PulseWidth16BitSet(RIGHT_ENCODER, PWM_MAX_DUTY_CYCLE);
    PLIB_OC_PulseWidth16BitSet(LEFT_ENCODER, PWM_MAX_DUTY_CYCLE);
    
    vTaskDelay(200);
    
    PLIB_OC_PulseWidth16BitSet(RIGHT_ENCODER, 0);
    PLIB_OC_PulseWidth16BitSet(LEFT_ENCODER, 0);
    
    // Set motor directions
    PLIB_PORTS_PinWrite(PORTS_ID_0, MOTOR_ONE_DIR_PORT, MOTOR_ONE_DIR_BIT, 1);
    PLIB_PORTS_PinWrite(PORTS_ID_0, MOTOR_TWO_DIR_PORT, MOTOR_TWO_DIR_BIT, 0);
    
    PLIB_OC_PulseWidth16BitSet(RIGHT_ENCODER, PWM_MAX_DUTY_CYCLE);
    PLIB_OC_PulseWidth16BitSet(LEFT_ENCODER, PWM_MAX_DUTY_CYCLE);
    
    vTaskDelay(TICKS_PER_90_TURN);
    
    PLIB_OC_PulseWidth16BitSet(RIGHT_ENCODER, 0);
    PLIB_OC_PulseWidth16BitSet(LEFT_ENCODER, 0);
    
    // Reset motor directions
    PLIB_PORTS_PinWrite(PORTS_ID_0, MOTOR_ONE_DIR_PORT, MOTOR_ONE_DIR_BIT, 0);
    PLIB_PORTS_PinWrite(PORTS_ID_0, MOTOR_TWO_DIR_PORT, MOTOR_TWO_DIR_BIT, 0);
}

void determine_state(){
    unsigned char buffer;
    if(xQueueReceive(motorQueue, &buffer, 5) == pdTRUE){
        switch(buffer){
        case 0:
            //dbgOutputVal(0x01);
            motor_threadData.state = MOTOR_THREAD_STATE_FORWARD;
            break;
        case 12:
            //dbgOutputVal(0x02);
            motor_threadData.state = MOTOR_THREAD_STATE_TURN_LEFT;
            break;
        case 8:
            //dbgOutputVal(0x03);
            motor_threadData.state = MOTOR_THREAD_STATE_ADJUST_TO_LEFT;
            break;
        case 3:
            //dbgOutputVal(0x04);
            motor_threadData.state = MOTOR_THREAD_STATE_TURN_RIGHT;
            break;
        case 1:
            //dbgOutputVal(0x05);
            motor_threadData.state = MOTOR_THREAD_STATE_ADJUST_TO_RIGHT;
            break;
        case 15:
            //dbgOutputVal(0x16);
            motor_threadData.state = MOTOR_THREAD_STATE_STOP;
            break;
        case 6:
            //dbgOutputVal(0x07);
            motor_threadData.state = MOTOR_THREAD_STATE_TURN_AROUND;
            break;
        default:
            //dbgOutputVal(0x08);
            motor_threadData.state = MOTOR_THREAD_STATE_STOP;
            break;
        }
    }
}


// *****************************************************************************
// *****************************************************************************
// Section: Application Initialization and State Machine Functions
// *****************************************************************************
// *****************************************************************************

void MOTOR_THREAD_Initialize ( void )
{
    /* Place the App state machine in its initial state. */
    motor_threadData.state = MOTOR_THREAD_STATE_INIT;

    left_encoder_count = 0;
    right_encoder_count = 0;
    
    while(motorQueue == NULL){}
    
    PLIB_INT_SourceEnable(INT_ID_0, INT_SOURCE_TIMER_2);
    PLIB_INT_SourceEnable(INT_ID_0, INT_SOURCE_TIMER_3);
    PLIB_INT_SourceEnable(INT_ID_0, INT_SOURCE_TIMER_4);
    
    DRV_OC0_Start();
    DRV_OC1_Start();
    
    DRV_TMR0_Start();
    DRV_TMR1_Start();
    DRV_TMR2_Start();
    
    // Set the motor directions
    PLIB_PORTS_PinWrite(PORTS_ID_0, MOTOR_ONE_DIR_PORT, MOTOR_ONE_DIR_BIT, 0);
    PLIB_PORTS_PinWrite(PORTS_ID_0, MOTOR_TWO_DIR_PORT, MOTOR_TWO_DIR_BIT, 0);
}

void MOTOR_THREAD_Tasks ( void )
{    
    /* Check the application's current state. */
    switch ( motor_threadData.state ){
        /* Application's initial state. */
        case MOTOR_THREAD_STATE_INIT:{
            motor_threadData.state = MOTOR_THREAD_STATE_STOP;
            break;
        }

        case MOTOR_THREAD_STATE_FORWARD:{
            left_encoder_count = 0;
            right_encoder_count = 0;
            
            // Until the state changes, P(ID) controller
            while(motor_threadData.state == MOTOR_THREAD_STATE_FORWARD){
                if(left_encoder_count < right_encoder_count){
                    // TODO increase left motor speed
                    PLIB_OC_PulseWidth16BitSet(LEFT_ENCODER, PWM_MAX_DUTY_CYCLE);
                    PLIB_OC_PulseWidth16BitSet(RIGHT_ENCODER, PWM_80_PERCENT);
                }else if(left_encoder_count > right_encoder_count){
                    // TODO increase right motor speed
                    PLIB_OC_PulseWidth16BitSet(LEFT_ENCODER, PWM_80_PERCENT);
                    PLIB_OC_PulseWidth16BitSet(RIGHT_ENCODER, PWM_MAX_DUTY_CYCLE);
                }else{
                    PLIB_OC_PulseWidth16BitSet(LEFT_ENCODER, PWM_90_PERCENT);
                    PLIB_OC_PulseWidth16BitSet(RIGHT_ENCODER, PWM_90_PERCENT);
                }
                determine_state();
            }
            break;
        }

        case MOTOR_THREAD_STATE_ADJUST_TO_LEFT:{
            // set left to 10%
            PLIB_OC_PulseWidth16BitSet(LEFT_ENCODER, PWM_10_PERCENT);
            // set right to 100%
            PLIB_OC_PulseWidth16BitSet(RIGHT_ENCODER, PWM_MAX_DUTY_CYCLE);
            
            break;
        }

        case MOTOR_THREAD_STATE_ADJUST_TO_RIGHT:{
            
            // set left to 100%
            PLIB_OC_PulseWidth16BitSet(LEFT_ENCODER, PWM_MAX_DUTY_CYCLE);
            // set right to 10%
            PLIB_OC_PulseWidth16BitSet(RIGHT_ENCODER, PWM_10_PERCENT);
            break;
        }

        case MOTOR_THREAD_STATE_TURN_LEFT:{
            turn_left();
            
            motor_threadData.state = MOTOR_THREAD_STATE_STOP;
            break;
        }
        
        case MOTOR_THREAD_STATE_TURN_RIGHT:{
            turn_right();
            
            motor_threadData.state = MOTOR_THREAD_STATE_STOP;
            break;
        }
        
        case MOTOR_THREAD_STATE_TURN_AROUND:{
            turn_around();
            
            motor_threadData.state = MOTOR_THREAD_STATE_STOP;            
            break;
        }
        
        case MOTOR_THREAD_STATE_TEST:{
            // Set motor directions
            turn_right();
            
            while(true){}
            
            break;
        }
        
        case MOTOR_THREAD_STATE_STOP:{
            PLIB_OC_PulseWidth16BitSet(LEFT_ENCODER, 0);
            PLIB_OC_PulseWidth16BitSet(RIGHT_ENCODER, 0);
            
            break;
        }    

        /* The default state should never be executed. */
        default:{
            dbgOutputVal(0xFF);
            while(1){}
        }
    }
    determine_state();
}

 

/*******************************************************************************
 End of File
 */
