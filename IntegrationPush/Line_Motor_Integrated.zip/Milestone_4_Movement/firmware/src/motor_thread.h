/*******************************************************************************
  MPLAB Harmony Application Header File

  Company:
    Microchip Technology Inc.

  File Name:
    motor_thread.h

  Summary:
    This header file provides prototypes and definitions for the application.

  Description:
    This header file provides function prototypes and data type definitions for
    the application.  Some of these are required by the system (such as the
    "APP_Initialize" and "APP_Tasks" prototypes) and some of them are only used
    internally by the application (such as the "APP_STATES" definition).  Both
    are defined here for convenience.
*******************************************************************************/

#ifndef _MOTOR_THREAD_H
#define _MOTOR_THREAD_H

// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************

#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdlib.h>
#include "system_config.h"
#include "system_definitions.h"

// DOM-IGNORE-BEGIN
#ifdef __cplusplus  // Provide C++ Compatibility

extern "C" {

#endif
// DOM-IGNORE-END 

// *****************************************************************************
// *****************************************************************************
// Section: Type Definitions
// *****************************************************************************
// *****************************************************************************

typedef enum
{
	/* Application's state machine's initial state. */
	MOTOR_THREAD_STATE_INIT=0,
    MOTOR_THREAD_STATE_FORWARD,
    MOTOR_THREAD_STATE_ADJUST_TO_LEFT,
    MOTOR_THREAD_STATE_ADJUST_TO_RIGHT,
    MOTOR_THREAD_STATE_TURN_LEFT,
    MOTOR_THREAD_STATE_TURN_RIGHT,
    MOTOR_THREAD_STATE_TURN_AROUND,
    MOTOR_THREAD_STATE_STOP,
            
    MOTOR_THREAD_STATE_TEST,

} MOTOR_THREAD_STATES;

typedef struct
{
    /* The application's current state */
    MOTOR_THREAD_STATES state;

    /* TODO: Define any additional data used by the application. */

} MOTOR_THREAD_DATA;

void increment_left_encoder(void);
void increment_right_encoder(void);

void MOTOR_THREAD_Initialize ( void );
void MOTOR_THREAD_Tasks( void );


#endif /* _MOTOR_THREAD_H */

//DOM-IGNORE-BEGIN
#ifdef __cplusplus
}
#endif
//DOM-IGNORE-END

/*******************************************************************************
 End of File
 */

