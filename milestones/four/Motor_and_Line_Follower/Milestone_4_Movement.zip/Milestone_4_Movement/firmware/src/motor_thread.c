/*******************************************************************************
  MPLAB Harmony Application Source File
  
  Company:
    Microchip Technology Inc.
  
  File Name:
    motor_thread.c

  Summary:
    This file contains the source code for the MPLAB Harmony application.

  Description:
    This file contains the source code for the MPLAB Harmony application.  It 
    implements the logic of the application's state machine and it may call 
    API routines of other MPLAB Harmony modules in the system, such as drivers,
    system services, and middleware.  However, it does not call any of the
    system interfaces (such as the "Initialize" and "Tasks" functions) of any of
    the modules in the system or make any assumptions about when those functions
    are called.  That is the responsibility of the configuration-specific system
    files.
 *******************************************************************************/

// DOM-IGNORE-BEGIN
/*******************************************************************************
Copyright (c) 2013-2014 released Microchip Technology Inc.  All rights reserved.

Microchip licenses to you the right to use, modify, copy and distribute
Software only when embedded on a Microchip microcontroller or digital signal
controller that is integrated into your product or third party product
(pursuant to the sublicense terms in the accompanying license agreement).

You should refer to the license agreement accompanying this Software for
additional information regarding your rights and obligations.

SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
(INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
 *******************************************************************************/
// DOM-IGNORE-END


// *****************************************************************************
// *****************************************************************************
// Section: Included Files 
// *****************************************************************************
// *****************************************************************************

#include "motor_thread.h"
#include "system_config/default/framework/driver/oc/drv_oc_static.h"
#include "peripheral/oc/plib_oc.h"
#include "message.h"
#include "debug.h"

// *****************************************************************************
// *****************************************************************************
// Section: Global Data Definitions
// *****************************************************************************
// *****************************************************************************

// *****************************************************************************

#define MOTOR_ONE_DIR_PORT  PORT_CHANNEL_C
#define MOTOR_ONE_DIR_BIT   PORTS_BIT_POS_14
#define MOTOR_ONE_PWM_PORT  PORT_CHANNEL_D
#define MOTOR_ONE_PWM_BIT   PORTS_BIT_POS_0

#define MOTOR_TWO_DIR_PORT  PORT_CHANNEL_G
#define MOTOR_TWO_DIR_BIT   PORTS_BIT_POS_1
#define MOTOR_TWO_PWM_PORT  PORT_CHANNEL_D
#define MOTOR_TWO_PWM_BIT   PORTS_BIT_POS_1

#define PWM_MAX_DUTY_CYCLE  655
#define PWM_90_PERCENT      590
#define PWM_80_PERCENT      524
#define PWM_70_PERCENT      459
#define PWM_60_PERCENT      393
#define PWM_50_PERCENT      328
#define PWM_40_PERCENT      262
#define PWM_30_PERCENT      197
#define PWM_20_PERCENT      131
#define PWM_10_PERCENT      66

#define TICKS_PER_90_TURN   50

MOTOR_THREAD_DATA motor_threadData;
extern QueueHandle_t motorQueue;
uint_fast32_t left_encoder_count, right_encoder_count;

// *****************************************************************************
// *****************************************************************************
// Section: Application Local Functions
// *****************************************************************************
// *****************************************************************************

void turn(){
    // zero the encoder counts, cuz they no longer matter
    left_encoder_count = 0;
    right_encoder_count = 0;
    while(true){
        if(left_encoder_count > TICKS_PER_90_TURN){ // 350 is just a guess TODO figure out how many encoder ticks is a turn
            // stop the left motor
            PLIB_PORTS_PinWrite(PORTS_ID_0, MOTOR_ONE_PWM_PORT, MOTOR_ONE_PWM_BIT, 0);
            
            while(right_encoder_count < TICKS_PER_90_TURN){}
            
            // stop the right motor
            PLIB_PORTS_PinWrite(PORTS_ID_0, MOTOR_TWO_PWM_PORT, MOTOR_TWO_PWM_BIT, 0);
            break;
        }
                
        if(right_encoder_count > TICKS_PER_90_TURN){
            // stop the right motor
            PLIB_PORTS_PinWrite(PORTS_ID_0, MOTOR_TWO_PWM_PORT, MOTOR_TWO_PWM_BIT, 0);
            
            while(left_encoder_count < TICKS_PER_90_TURN){}
            
            // stop the left motor
            PLIB_PORTS_PinWrite(PORTS_ID_0, MOTOR_ONE_PWM_PORT, MOTOR_ONE_PWM_BIT, 0);
            break;
        }
    }
    // zero the encoder counts again, so the correction can proceed
    left_encoder_count = 0;
    right_encoder_count = 0;
}

void determine_state(){
    unsigned char buffer;
    if(xQueueReceive(motorQueue, &buffer, 5) == pdTRUE){
        dbgOutputVal(0xEE);
        switch(buffer){
        case 0:
            dbgOutputVal(0x01);
            motor_threadData.state = MOTOR_THREAD_STATE_FORWARD;
            break;
        case 12:
            dbgOutputVal(0x02);
            motor_threadData.state = MOTOR_THREAD_STATE_TURN_LEFT;
            break;
        case 8:
            dbgOutputVal(0x03);
            motor_threadData.state = MOTOR_THREAD_STATE_ADJUST_TO_LEFT;
            break;
        case 3:
            dbgOutputVal(0x04);
            motor_threadData.state = MOTOR_THREAD_STATE_TURN_RIGHT;
            break;
        case 1:
            dbgOutputVal(0x05);
            motor_threadData.state = MOTOR_THREAD_STATE_ADJUST_TO_RIGHT;
            break;
        case 15:
            dbgOutputVal(0x16);
            motor_threadData.state = MOTOR_THREAD_STATE_STOP;
            break;
        case 6:
            dbgOutputVal(0x07);
            motor_threadData.state = MOTOR_THREAD_STATE_TURN_LEFT;
            break;
        default:
            dbgOutputVal(0x08);
            motor_threadData.state = MOTOR_THREAD_STATE_STOP;
            break;
        }
    }
}


// *****************************************************************************
// *****************************************************************************
// Section: Application Initialization and State Machine Functions
// *****************************************************************************
// *****************************************************************************

void MOTOR_THREAD_Initialize ( void )
{
    /* Place the App state machine in its initial state. */
    motor_threadData.state = MOTOR_THREAD_STATE_INIT;

    left_encoder_count = 0;
    right_encoder_count = 0;
    
    while(motorQueue == NULL){}
    
    PLIB_INT_SourceEnable(INT_ID_0, INT_SOURCE_TIMER_2);
    PLIB_INT_SourceEnable(INT_ID_0, INT_SOURCE_TIMER_3);
    PLIB_INT_SourceEnable(INT_ID_0, INT_SOURCE_TIMER_4);
    
    DRV_OC0_Start();
    DRV_OC1_Start();
    
    DRV_TMR0_Start();
    DRV_TMR1_Start();
    DRV_TMR2_Start();
}

void MOTOR_THREAD_Tasks ( void )
{    
    /* Check the application's current state. */
    switch ( motor_threadData.state ){
        /* Application's initial state. */
        case MOTOR_THREAD_STATE_INIT:{
            motor_threadData.state = MOTOR_THREAD_STATE_STOP;
            break;
        }

        case MOTOR_THREAD_STATE_FORWARD:{
            // Set the motor directions
            PLIB_PORTS_PinWrite(PORTS_ID_0, MOTOR_ONE_DIR_PORT, MOTOR_ONE_DIR_BIT, 0);
            PLIB_PORTS_PinWrite(PORTS_ID_0, MOTOR_TWO_DIR_PORT, MOTOR_TWO_DIR_BIT, 0);
            
            // Make sure the motors are going
            PLIB_PORTS_PinWrite(PORTS_ID_0, MOTOR_ONE_PWM_PORT, MOTOR_ONE_PWM_BIT, 1);
            PLIB_PORTS_PinWrite(PORTS_ID_0, MOTOR_TWO_PWM_PORT, MOTOR_TWO_PWM_BIT, 1);
            
            left_encoder_count = 0;
            right_encoder_count = 0;
            
            // Until the state changes, P(ID) controller
            while(motor_threadData.state == MOTOR_THREAD_STATE_FORWARD){
                if(left_encoder_count < right_encoder_count){
                    // TODO increase left motor speed
                    PLIB_OC_PulseWidth16BitSet(OC_ID_1, PWM_MAX_DUTY_CYCLE);
                    PLIB_OC_PulseWidth16BitSet(OC_ID_2, PWM_80_PERCENT);
                }else if(left_encoder_count > right_encoder_count){
                    // TODO increase right motor speed
                    PLIB_OC_PulseWidth16BitSet(OC_ID_1, PWM_80_PERCENT);
                    PLIB_OC_PulseWidth16BitSet(OC_ID_2, PWM_MAX_DUTY_CYCLE);
                }else{
                    PLIB_OC_PulseWidth16BitSet(OC_ID_1, PWM_90_PERCENT);
                    PLIB_OC_PulseWidth16BitSet(OC_ID_2, PWM_90_PERCENT);
                }
                determine_state();
            }
            break;
        }

        case MOTOR_THREAD_STATE_ADJUST_TO_LEFT:{
            // set left to 80%
            PLIB_OC_PulseWidth16BitSet(OC_ID_1, PWM_10_PERCENT);
            // set right to 100%
            PLIB_OC_PulseWidth16BitSet(OC_ID_2, PWM_MAX_DUTY_CYCLE);
            
            break;
        }

        case MOTOR_THREAD_STATE_ADJUST_TO_RIGHT:{
            // set left to 100%
            PLIB_OC_PulseWidth16BitSet(OC_ID_1, PWM_MAX_DUTY_CYCLE);
            // set right to 80%
            PLIB_OC_PulseWidth16BitSet(OC_ID_2, PWM_10_PERCENT);
            break;
        }

        case MOTOR_THREAD_STATE_TURN_LEFT:{
            // Set motor directions
            PLIB_PORTS_PinWrite(PORTS_ID_0, MOTOR_ONE_DIR_PORT, MOTOR_ONE_DIR_BIT, 1);
            PLIB_PORTS_PinWrite(PORTS_ID_0, MOTOR_TWO_DIR_PORT, MOTOR_TWO_DIR_BIT, 0);
            
            PLIB_OC_PulseWidth16BitSet(OC_ID_1, PWM_MAX_DUTY_CYCLE);
            PLIB_OC_PulseWidth16BitSet(OC_ID_2, PWM_MAX_DUTY_CYCLE);
            
            turn();
            
            motor_threadData.state = MOTOR_THREAD_STATE_TURN_RIGHT;
            break;
        }
        
        case MOTOR_THREAD_STATE_TURN_RIGHT:{
            // Set motor directions
            PLIB_PORTS_PinWrite(PORTS_ID_0, MOTOR_ONE_DIR_PORT, MOTOR_ONE_DIR_BIT, 0);
            PLIB_PORTS_PinWrite(PORTS_ID_0, MOTOR_TWO_DIR_PORT, MOTOR_TWO_DIR_BIT, 1);
            
            PLIB_OC_PulseWidth16BitSet(OC_ID_1, PWM_MAX_DUTY_CYCLE);
            PLIB_OC_PulseWidth16BitSet(OC_ID_2, PWM_MAX_DUTY_CYCLE);
            
            turn();
            
            motor_threadData.state = MOTOR_THREAD_STATE_STOP;
            break;
        }
        
        case MOTOR_THREAD_STATE_TURN_AROUND:{
            // Set motor directions
            PLIB_PORTS_PinWrite(PORTS_ID_0, MOTOR_ONE_DIR_PORT, MOTOR_ONE_DIR_BIT, 1);
            PLIB_PORTS_PinWrite(PORTS_ID_0, MOTOR_TWO_DIR_PORT, MOTOR_TWO_DIR_BIT, 0);
            
            PLIB_OC_PulseWidth16BitSet(OC_ID_1, PWM_MAX_DUTY_CYCLE);
            PLIB_OC_PulseWidth16BitSet(OC_ID_2, PWM_MAX_DUTY_CYCLE);
            
            // two left turns should do the trick
            turn();
            turn();
            
            motor_threadData.state = MOTOR_THREAD_STATE_STOP;            
            break;
        }
        
        case MOTOR_THREAD_STATE_TEST:{
            // Set motor directions
            PLIB_PORTS_PinWrite(PORTS_ID_0, MOTOR_ONE_DIR_PORT, MOTOR_ONE_DIR_BIT, 1);
            PLIB_PORTS_PinWrite(PORTS_ID_0, MOTOR_TWO_DIR_PORT, MOTOR_TWO_DIR_BIT, 1);
            
            PLIB_PORTS_PinWrite(PORTS_ID_0, MOTOR_ONE_PWM_PORT, MOTOR_ONE_PWM_BIT, 1);
            PLIB_PORTS_PinWrite(PORTS_ID_0, MOTOR_TWO_PWM_PORT, MOTOR_TWO_PWM_BIT, 1);
            
            PLIB_OC_PulseWidth16BitSet(OC_ID_1, PWM_MAX_DUTY_CYCLE);
            PLIB_OC_PulseWidth16BitSet(OC_ID_2, 100);
            
            while(1){}
            
            break;
        }
        
        case MOTOR_THREAD_STATE_STOP:{
            PLIB_OC_PulseWidth16BitSet(OC_ID_1, 0);
            PLIB_OC_PulseWidth16BitSet(OC_ID_2, 0);
            
            break;
        }    

        /* The default state should never be executed. */
        default:{
            dbgOutputVal(0xFF);
            while(1){}
        }
    }
    determine_state();
}

 

/*******************************************************************************
 End of File
 */
