/*******************************************************************************
  MPLAB Harmony Application Source File
  
  Company:
    Microchip Technology Inc.
  
  File Name:
    app.c

  Summary:
    This file contains the source code for the MPLAB Harmony application.

  Description:
    This file contains the source code for the MPLAB Harmony application.  It 
    implements the logic of the application's state machine and it may call 
    API routines of other MPLAB Harmony modules in the system, such as drivers,
    system services, and middleware.  However, it does not call any of the
    system interfaces (such as the "Initialize" and "Tasks" functions) of any of
    the modules in the system or make any assumptions about when those functions
    are called.  That is the responsibility of the configuration-specific system
    files.
 *******************************************************************************/

// DOM-IGNORE-BEGIN
/*******************************************************************************
Copyright (c) 2013-2014 released Microchip Technology Inc.  All rights reserved.

Microchip licenses to you the right to use, modify, copy and distribute
Software only when embedded on a Microchip microcontroller or digital signal
controller that is integrated into your product or third party product
(pursuant to the sublicense terms in the accompanying license agreement).

You should refer to the license agreement accompanying this Software for
additional information regarding your rights and obligations.

SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
(INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
 *******************************************************************************/
// DOM-IGNORE-END


// *****************************************************************************
// *****************************************************************************
// Section: Included Files 
// *****************************************************************************
// *****************************************************************************

#include "motor_thread.h"
#include "system_config/default/framework/driver/oc/drv_oc_static.h"
#include "peripheral/oc/plib_oc.h"

// *****************************************************************************
// *****************************************************************************
// Section: Global Data Definitions
// *****************************************************************************
// *****************************************************************************

// *****************************************************************************
/* Application Data

  Summary:
    Holds application data

  Description:
    This structure holds the application's data.

  Remarks:
    This structure should be initialized by the APP_Initialize function.
    
    Application strings and buffers are be defined outside this structure.
*/

APP_DATA appData;
extern QueueHandle_t motorQueue;
uint_fast32_t left_encoder_count, right_encoder_count;

// *****************************************************************************
// *****************************************************************************
// Section: Application Local Functions
// *****************************************************************************
// *****************************************************************************

#define MOTOR_ONE_DIR_PORT  PORT_CHANNEL_C
#define MOTOR_ONE_DIR_BIT   PORTS_BIT_POS_14
#define MOTOR_ONE_PWM_PORT  PORT_CHANNEL_D
#define MOTOR_ONE_PWM_BIT   PORTS_BIT_POS_0

#define MOTOR_TWO_DIR_PORT  PORT_CHANNEL_G
#define MOTOR_TWO_DIR_BIT   PORTS_BIT_POS_1
#define MOTOR_TWO_PWM_PORT  PORT_CHANNEL_D
#define MOTOR_TWO_PWM_BIT   PORTS_BIT_POS_1

// *****************************************************************************
// *****************************************************************************
// Section: Application Initialization and State Machine Functions
// *****************************************************************************
// *****************************************************************************

void encoder_a_interrupt(){
    left_encoder_count++;
}

void encoder_b_interrupt(){
    right_encoder_count++;
}

void turn(){
    while(true){
        if(left_encoder_count > 350){ // 350 is just a guess TODO figure out how many encoder ticks is a turn
            // stop the left motor
            PLIB_PORTS_PinWrite(PORTS_ID_0, MOTOR_ONE_PWM_PORT, MOTOR_ONE_PWM_BIT, 0);
            while(right_encoder_count < 350){}
                // stop the right motor
                PLIB_PORTS_PinWrite(PORTS_ID_0, MOTOR_TWO_PWM_PORT, MOTOR_TWO_PWM_BIT, 0);
                break;
        }
                
        if(right_encoder_count > 350){
            // stop the right motor
            PLIB_PORTS_PinWrite(PORTS_ID_0, MOTOR_TWO_PWM_PORT, MOTOR_TWO_PWM_BIT, 0);
            while(left_encoder_count < 350){}
                // stop the left motor
                PLIB_PORTS_PinWrite(PORTS_ID_0, MOTOR_ONE_PWM_PORT, MOTOR_ONE_PWM_BIT, 0);
                break;
        }
    }
}

void determine_state(){
    if(uxQueueMessagesWaiting(motorQueue)){
        
    }
}

void APP_Initialize ( void )
{
    /* Place the App state machine in its initial state. */
    appData.state = APP_STATE_INIT;

    left_encoder_count = 0;
    right_encoder_count = 0;
    
    while(motorQueue == NULL){}
}

void APP_Tasks ( void )
{    
    /* Check the application's current state. */
    switch ( appData.state )
    {
        /* Application's initial state. */
        case APP_STATE_INIT:
        {
            bool appInitialized = true;
            if (appInitialized)
            {
                appData.state = STOP;
            }
            break;
        }

        case FORWARD:
        {
            // Make sure the motors are going
            PLIB_PORTS_PinWrite(PORTS_ID_0, MOTOR_ONE_PWM_PORT, MOTOR_ONE_PWM_BIT, 1);
            PLIB_PORTS_PinWrite(PORTS_ID_0, MOTOR_TWO_PWM_PORT, MOTOR_TWO_PWM_BIT, 1);
            
            // Set the motor directions
            PLIB_PORTS_PinWrite(PORTS_ID_0, MOTOR_ONE_DIR_PORT, MOTOR_ONE_DIR_BIT, 0);
            PLIB_PORTS_PinWrite(PORTS_ID_0, MOTOR_TWO_DIR_PORT, MOTOR_TWO_DIR_BIT, 0);
            
            // Until the state changes, P(ID) controller
            while(appData.state == FORWARD){
                if(left_encoder_count < right_encoder_count){
                    // TODO increase left motor speed
                    PLIB_OC_PulseWidth16BitSet(OC_ID_1, 100);
                }else if(left_encoder_count > right_encoder_count){
                    // TODO increase right motor speed
                    PLIB_OC_PulseWidth16BitSet(OC_ID_1, 100);
                }
            }
            break;
        }

        case ADJUST_TO_LEFT:
        {
            // TODO set left to 90%
            PLIB_OC_PulseWidth16BitSet(OC_ID_1, 100);
            // TODO set right to 100%
            PLIB_OC_PulseWidth16BitSet(OC_ID_1, 100);
            
            break;
        }

        case ADJUST_TO_RIGHT:
        {
            // TODO set left to 100%
            // TODO set right to 90%
            break;
        }

        case TURN_LEFT:
        {
            // TODO start ignoring messages from line sensor
            // Set motor directions
            PLIB_PORTS_PinWrite(PORTS_ID_0, MOTOR_ONE_DIR_PORT, MOTOR_ONE_DIR_BIT, 1);
            PLIB_PORTS_PinWrite(PORTS_ID_0, MOTOR_TWO_DIR_PORT, MOTOR_TWO_DIR_BIT, 0);
            
            turn();
            
            appData.state = STOP;
            // TODO stop ignoring messages from line sensor
            break;
        }
        
        case TURN_RIGHT:
        {
            // Set motor directions
            PLIB_PORTS_PinWrite(PORTS_ID_0, MOTOR_ONE_DIR_PORT, MOTOR_ONE_DIR_BIT, 0);
            PLIB_PORTS_PinWrite(PORTS_ID_0, MOTOR_TWO_DIR_PORT, MOTOR_TWO_DIR_BIT, 1);
            
            turn();
            
            appData.state = STOP;
            // TODO stop ignoring messages from line sensor
            break;
        }
        
        case STOP:
        {
            PLIB_PORTS_PinWrite(PORTS_ID_0, MOTOR_ONE_PWM_PORT, MOTOR_ONE_PWM_BIT, 0);
            PLIB_PORTS_PinWrite(PORTS_ID_0, MOTOR_TWO_PWM_PORT, MOTOR_TWO_PWM_BIT, 0);
            break;
        }    

        /* The default state should never be executed. */
        default:
        {
            /* TODO: Handle error in application's state machine. */
            break;
        }
    }
}

 

/*******************************************************************************
 End of File
 */
